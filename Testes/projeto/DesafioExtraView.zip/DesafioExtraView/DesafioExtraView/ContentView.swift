//
//  ContentView.swift
//  DesafioExtraView
//
//  Created by Jairo Júnior on 14/04/23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        let numero : Int = 2
        
        VStack {
            Text("Academy App")
            ZStack{
                Circle()
                Text("⭑")
                    .colorInvert()
                    .font(.system(size: 120))
                    .offset(x:0, y:-10)
            }.padding(.bottom)
            HStack{
                ForEach(1...numero, id:\.self){_ in
                    RoundedRectangle(cornerRadius: 25)
                }
            }
            HStack{
                ForEach(1...numero, id:\.self){_ in
                    Rectangle()
                }
            }
            HStack{
                VStack{
                    Image(systemName: "house")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                        .foregroundColor(.blue)
                    Text("House")
                }.padding()
            HStack{
                VStack{
                    Image(systemName: "pencil")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                        .foregroundColor(.blue)
                    Text("Activities")
                }.padding()
                VStack{
                    Image(systemName: "trophy")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 25)
                        .foregroundColor(.blue)
                    Text("Ranking")
                }.padding()
            }.padding()
        }.padding()
    }.padding()
}
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}

