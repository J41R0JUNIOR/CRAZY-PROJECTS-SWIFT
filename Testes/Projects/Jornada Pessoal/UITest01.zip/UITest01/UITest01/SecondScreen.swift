//
//  SecondScreenViewController.swift
//  UITest01
//
//  Created by Jairo Júnior on 11/09/23.
//

import UIKit

class SecondScreen: UIViewController {
    var testToggle = false
    let buttonToChange = UIButton()


    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        title = "Second Screen"
        navigationController?.navigationBar.prefersLargeTitles = true

        buttonToChangeColor()

    }
    @objc func changeColor(){
        self.view.backgroundColor = testToggle == true ? .red : .blue
        testToggle.toggle()
    }
    
    func buttonToChangeColor(){
        view.addSubview(buttonToChange)
        
        buttonToChange.translatesAutoresizingMaskIntoConstraints = false
        buttonToChange.configuration = .filled()
        buttonToChange.configuration?.baseBackgroundColor = .white
        buttonToChange.configuration?.title = ""
        buttonToChange.addTarget(self, action: #selector(changeColor), for: .touchUpInside)
        buttonToChange.alpha = 0.3
        
        NSLayoutConstraint.activate([
            buttonToChange.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            buttonToChange.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            buttonToChange.widthAnchor.constraint(equalToConstant: 50),
            buttonToChange.heightAnchor.constraint(equalToConstant: 50)
        ])
    }
}
