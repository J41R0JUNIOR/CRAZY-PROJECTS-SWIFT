//
//  Desafio01ViewApp.swift
//  Desafio01View
//
//  Created by Jairo Júnior on 14/04/23.
//

import SwiftUI

@main
struct Desafio01ViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
