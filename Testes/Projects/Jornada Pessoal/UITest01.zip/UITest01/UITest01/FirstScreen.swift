//
//  ViewController.swift
//  UITest01
//
//  Created by Jairo Júnior on 11/09/23.
//

import UIKit

class FirstScreen: UIViewController {

    let button = UIButton()
    
    override func viewDidLoad() {
        view.backgroundColor = .systemBackground
        setUp()
        squares()
        title = "First Screen"
        navigationController?.navigationBar.prefersLargeTitles = true
        
        
    }
    
    func squares(){
        let myView = UIView(frame: CGRect(x: 50, y: 200, width: 200, height: 100))
        myView.backgroundColor = .blue        
    
        
        let myView2 = UIView(frame: CGRect(x: 50, y: 40, width: 200, height: 100))
        myView2.backgroundColor = .darkGray
        myView2.alpha = 0.8

                
    
        let myView3 = UIView(frame: CGRect(x: 50, y: 500, width: 50, height: 50))
        myView3.backgroundColor = .blue
        
        myView3.clipsToBounds = false

    
        
        let myView4 = UIView(frame: CGRect(x: 40, y: 40, width: 50, height: 50))
        myView4.backgroundColor = .yellow

       
        view.addSubview(myView)
        myView.addSubview(myView2)
        view.addSubview(myView3)
        myView3.addSubview(myView4)
    }
    
    func setUp(){
        
        view.addSubview(button)
        
        button.configuration = .filled()
        button.configuration?.baseBackgroundColor = .red
        button.configuration?.title = "Next View"
        
        button.addTarget(self, action: #selector(goToNextScreen), for: .touchUpInside)
        button.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            button.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            button.widthAnchor.constraint(equalToConstant: 200),
            button.heightAnchor.constraint(equalToConstant: 50)
        ])
        
    }
    @objc func goToNextScreen(){
        let nextScreen = SecondScreen()
        navigationController?.pushViewController(nextScreen, animated: true)
    }
}


