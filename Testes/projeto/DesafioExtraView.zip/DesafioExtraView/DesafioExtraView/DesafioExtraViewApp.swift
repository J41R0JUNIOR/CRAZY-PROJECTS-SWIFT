//
//  DesafioExtraViewApp.swift
//  DesafioExtraView
//
//  Created by Jairo Júnior on 14/04/23.
//

import SwiftUI

@main
struct DesafioExtraViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
