//
//  ContentView.swift
//  V1.0
//
//  Created by Jairo Júnior on 14/04/23.
//

import SwiftUI
class Aluno{
    var nome:String
    var numeroDoKit:Int
    
    init(nome: String, numeroDoKit: Int) {
        self.nome = nome
        self.numeroDoKit = numeroDoKit
    }
}
var estudante = Aluno(nome: "Jairo", numeroDoKit: 619)


struct ContentView: View {
    var body: some View {
        
        VStack{
            Text("Exercício")
            HStack{
                Rectangle()
                    .frame(width: 115, height: 300)
                Rectangle()
                    .frame(width: 115, height: 300)
                Rectangle()
                    .frame(width: 115, height: 300)
            }
            Rectangle()
                .frame(width: 360, height: 100)
            Rectangle()
                .frame(width: 360, height: 100)
            Rectangle()
                .frame(width: 360, height: 100)
            Text("Estudante: \(estudante.nome) do Kit: \(estudante.numeroDoKit)\nEu sou FERA!!!")
        }
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
